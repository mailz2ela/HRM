import React from "react";
import navbar from './navbar.css'
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Navbar(){
    return (
        <div className='navbar-container'>
            <ul className='navbar-content'>
                <li>Customer Management</li>
                <li>Supplier Management</li>
                <li>Inventory Management</li>
                <li>Order Management</li>
                <Link to='/hrm'><li>HR Management</li></Link>
                <li>Reports</li>
            </ul>
        </div>
    )
}

export default Navbar;