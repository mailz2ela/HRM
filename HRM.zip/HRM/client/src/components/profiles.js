import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import axios  from "axios";

function Profiles(props){
    
    var individualEmployee  = props.employeeList.map((item,index)=>{

        var deleteTask = (id)=>{
            axios.delete(`http://localhost:8080/api/hrm/${id}`).then(res=>{
                props.taskDelete(res.data)
                alert('Data deleted Successfully')
            }).catch(err=>console.log(err))
        }
        
        return <table key={index}>            
            <tr>
                <td>{item.employeeId}</td>
                <Link to={`/hrm/profiles/profile/${item._id}`}><td>{item.name}</td></Link>
                <td>{item.gender}</td>
                <td>{item.maritalStatus}</td>
                <td>{item.dob}</td>
                <td>{item.emailId}</td>
                <Link to={`/hrm/profiles/editprofile/${item._id}`}><td><button>Edit</button></td></Link>
                <td><button onClick={()=>deleteTask(item._id)}>Delete</button></td>
            </tr>         

        </table>
    })
    
    
    return (
        <div>
            <h3>Employee Lists</h3>
            <div>
            <tr>
                <th>EMP ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Marital Status</th>
                <th>DOB</th>
                <th>Email ID</th>
            </tr> 
            </div>
            <div>
                {individualEmployee}
            </div>
        </div>
    )
}


export default Profiles;