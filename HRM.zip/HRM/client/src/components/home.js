import React from "react";
import home from './home.css';

function Home(){
    return (
        <div className='title'>
            <h3>Welcome to BRM</h3>
        </div>
    )
}

export default Home;