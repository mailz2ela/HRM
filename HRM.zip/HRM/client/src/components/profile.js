import axios from "axios";
import React, { useEffect, useState } from "react";

function Profile(props){

    const [employee,Setemployee] = useState([])

    useEffect(()=>{
        axios.get(`http://localhost:8080/api/hrm/${props.match.params.id}`).then(res=>Setemployee(res.data)).catch(err=>console.log(err))
    },[])

    console.log(employee)

    var newSingleEmployee = [employee];
    console.log(newSingleEmployee)

    var singleEmployee = newSingleEmployee.map((item,index)=>{
        return <li key={index}>
            <h3>Hello {item.name}</h3>
            <div>EMP : {item.employeeId}</div>
            <div>Name : {item.name}</div>
            <div>Gender : {item.gender}</div>
            <div>DOB : {item.dob}</div>
            <div>Status : {item.maritalStatus}</div>
            <div>Email : {item.emailId}</div>
        </li>
    })
    
    return (
        <div>
            <ul>
                {singleEmployee}
            </ul>
        </div>
    )
}

export default Profile;