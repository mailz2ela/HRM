import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Editprofile(props){

    const [empId,SetempId] = useState('');
    const [name,Setname] = useState('');
    const [gender,Setgender] = useState('');
    const [maritalStatus, SetmaritalStatus] = useState('');
    const [dob,Setdob] = useState('');
    const [email,Setemail] = useState('');

    useEffect(()=>{
        axios.get(`http://localhost:8080/api/hrm/${props.match.params.id}`).then(res=>{

            console.log(res.data)

            Setname(res.data.name);
            SetempId(res.data.employeeId);
            Setgender(res.data.gender);
            SetmaritalStatus(res.data.maritalStatus);
            Setdob(res.data.dob);
            Setemail(res.data.emailId);
            }).catch(err=>console.log(err))
        },[])

        var updateData = {
            name:name,
            employeeId:empId,
            gender:gender,
            maritalStatus:maritalStatus,
            dob:dob,
            emailId:email
        };        

        var mySubmit = (e)=>{
            
            axios.put(`http://localhost:8080/api/hrm/${props.match.params.id}`,updateData).then(res=>{                
                props.employeeList(res.data)
                alert('Data Updated Successfully')
        }).catch(err=>console.log(err))
        }
    return (
        <div>
            <div>
                <h3>
                    Update Employee!
                </h3>
            </div>
            <form autoComplete='off' onSubmit={mySubmit}>
                <div>
                    <label>Employee ID : </label><br></br>
                    <input type='text' value={empId} onChange={(event)=>{SetempId(event.target.value)}}></input>
                </div>
                <div>
                    <label>Name : </label><br></br>
                    <input type='text' value={name} onChange={(event)=>{Setname(event.target.value)}}></input>
                </div>
                <div>
                    <label>Gender : </label><br></br>
                    <select type='text' value={gender} onChange={(event)=>{Setgender(event.target.value)}}>
                        <option>--Select--</option>
                        <option>Male</option>
                        <option>Female</option>
                    </select>
                </div>
                <div>
                    <label>Marital Status : </label><br></br>
                    <select type='text' value={maritalStatus} onChange={(event)=>{SetmaritalStatus(event.target.value)}}>
                        <option>--Select--</option>
                        <option>Married</option>
                        <option>Single</option>
                    </select>
                </div>
                <div>
                    <label>DOB : </label><br></br>
                    <input type='Date' value={dob} onChange={(event)=>{Setdob(event.target.value)}}></input>
                </div>
                <div>
                    <label>Email ID : </label><br></br>
                    <input type='text' value={email} onChange={(event)=>{Setemail(event.target.value)}}></input>
                </div><br></br>
                <div>
                    <input type='submit' className='button'></input>    
                </div>                
            </form>
        </div>
        
    )
}

export default Editprofile;