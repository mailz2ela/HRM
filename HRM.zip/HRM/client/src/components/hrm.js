import React from "react";
import hrm from './hrm.css';
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function HRM(){
    return (
        <div className='hrm-container'>
            <ul className='hrm-content'>
                <Link to='/hrm/hirepeople'><li>Hire People</li></Link>
                <Link to='/hrm/profiles'><li>People Profile</li></Link>
                <li>Salary</li>
                <li>Leave Tracker</li>
            </ul>
        </div>
    )
}

export default HRM;