import React, { useEffect, useState } from 'react';
import axios from 'axios';
import peopleprofile from './peopleprofile.css';
import Profiles from './profiles';

function Peopleprofile(){

    const [employeeList,SetemployeeList] = useState([]);

    useEffect(()=>{
        axios.get('http://localhost:8080/api/hrm').then(res=>SetemployeeList(res.data)).catch(err=>console.log(err))
    },[])
    console.log(employeeList)
    var taskDelete = item =>{
        var newEmployeeList = employeeList.filter(task=>!(item._id===task._id))
        SetemployeeList(newEmployeeList)
}  

    return (
        <div>
            <Profiles employeeList={employeeList} taskDelete={taskDelete}/>
        </div>
    )
}


export default Peopleprofile;