import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';
import Home from './components/home';
import Navbar from './components/navbar';
import HRM from './components/hrm';
import Peopleprofile from './components/peopleprofile';
import axios from 'axios';
import Hirepeople from './components/hirepeople';
import Profiles from './components/profiles';
import Profile from './components/profile';
import Editprofile from './components/editprofile';

function App(){ 

  const [employeeList,SetemployeeList] = useState([]);

    useEffect(()=>{
        axios.get('http://localhost:8080/api/hrm').then(res=>SetemployeeList(res.data)).catch(err=>console.log(err))
    },[])

  return (
    <div>
        <Route  path='/' component={Home}></Route>
        <Route  path='/' component={Navbar}></Route>
        <Route  path='/hrm' component={HRM}></Route>
        <Route  exact path='/hrm/profiles/' render={()=><Peopleprofile />}></Route>
        <Route  exact path='/hrm/hirepeople/' component={Hirepeople}></Route>  
        <Route  path='/hrm/profiles/profile/:id/' render={(props)=><Profile {...props} employeeList={employeeList}/>}></Route>
        <Route  path='/hrm/profiles/editprofile/:id/' render={(props)=><Editprofile {...props} employeeList={employeeList}/>}></Route> 

    </div>
  )
}

export default App;