var mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
    employeeId:{
        type:String,
        default:'EMP7000'
    },
    name:String,
    gender:String,
    maritalStatus:String,
    dob:String,
    emailId:String
})

const Task = mongoose.model('hrm',TaskSchema);

module.exports = Task;