var express = require('express');
var app = express();
var mongoose = require('mongoose');
var url = 'mongodb://localhost:27017/CRUD';
var router = require('./routes')
var cors = require('cors');

app.use(express.json())
app.use(cors())
app.use('/api/hrm', router)

app.listen(8080,function(err){
    if(err)console.log(err)
    console.log('Server Started at port : 8080')
})

mongoose.connect(url,function(err){
    if(err)console.log(err)
    console.log('Database Connected Successfully')
})