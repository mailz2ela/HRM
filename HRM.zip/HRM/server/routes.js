var express = require('express');
var router = express.Router();
var Task = require('../server/model');

router.get('/',function(req,res){
     Task.find((err,docs)=>{
         if(err)console.log(err)
         res.json(docs)
     })
})

router.post('/',function(req,res){
    var task = new Task(req.body)
    task.save((err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
    })   
})

router.get('/:id',function(req,res){
    Task.findById(req.params.id,(err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
    })
})

router.delete('/:id',function(req,res){
    Task.findByIdAndDelete(req.params.id,(err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
    })
})

router.put('/:id',function(req,res){
    Task.findByIdAndUpdate(req.params.id,req.body,{new:true},(err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
    })
})

module.exports = router;